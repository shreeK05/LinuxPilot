from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.orm import Session
from typing import List, Dict, Any
from app.db.session import get_db
from app.models.domain import Task as DBTask
from app.schemas.task import TaskCreate, TaskResponse
from app.repositories.agent_repo import update_task_state, create_approval, save_plan, log_audit_event, get_audit_events
from app.api.deps import get_current_user
from app.models.domain import User
from app.agent.orchestrator import AgentOrchestrator
from app.agent.goal_understanding import DeterministicGoalInterpreter
from app.agent.planner import DeterministicPlanner
from app.agent.policy import PolicyEngine
from app.agent.executor import ExecutionEngine
from app.agent.verifier import DeterministicVerifier
from app.agent.recovery import RecoveryEngine
from app.agent.context import ExecutionContext
from app.agent.actions.registry import action_registry
from app.agent.models import AgentState

from app.db.session import SessionLocal

router = APIRouter()

def run_agent_lifecycle(task_id: str, goal: str):
    # Setup context
    context = ExecutionContext(task_id=task_id)

    db = SessionLocal()
    try:
        from app.core.logging import log_event
        from app.core.metrics import (
            TASKS_COMPLETED, TASKS_FAILED, TASK_DURATION,
            STEP_LATENCY, STEP_VERIFICATION_FAILURES, STEP_RETRIES,
            STEP_REPLANS, STEP_ROLLBACKS, APPROVAL_WAITS, SANDBOX_VIOLATIONS,
            ACTIVE_TASKS
        )
        import time

        start_time = time.time()

        # State change callback
        def on_state_change(transition, ctx):
            update_task_state(db, ctx.task_id, transition.to_state)

            # Update metrics
            ACTIVE_TASKS.labels(status=transition.to_state.value).inc()
            if transition.from_state:
                ACTIVE_TASKS.labels(status=transition.from_state.value).dec()

            if transition.to_state == AgentState.COMPLETED:
                TASKS_COMPLETED.inc()
                TASK_DURATION.observe(time.time() - start_time)
            elif transition.to_state == AgentState.FAILED:
                TASKS_FAILED.inc()
            elif transition.to_state == AgentState.WAITING_APPROVAL:
                APPROVAL_WAITS.inc()
                create_approval(db, transition, ctx)
            elif transition.to_state == AgentState.REPLANNING:
                STEP_REPLANS.inc()
            elif transition.to_state == AgentState.RETRYING:
                STEP_RETRIES.inc()
            elif transition.to_state == AgentState.ROLLING_BACK:
                STEP_ROLLBACKS.inc()

            log_event(
                event_type="STATE_TRANSITION",
                status="SUCCESS",
                component="orchestrator",
                task_id=ctx.task_id,
                message=f"Transitioned to {transition.to_state.value}"
            )

        # Audit callback
        def on_audit_event(event_type, status, metadata, ctx):
            log_audit_event(db, ctx.task_id, event_type, status, metadata)

            if event_type == "VERIFICATION_COMPLETED" and status == "FAILED":
                STEP_VERIFICATION_FAILURES.inc()
            if event_type == "POLICY_EVALUATION" and status == "BLOCKED":
                if metadata.get("reason", "").lower().find("sandbox") != -1:
                    SANDBOX_VIOLATIONS.inc()
            if event_type == "ACTION_EXECUTED" and status == "SUCCESS":
                latency = metadata.get("latency_ms", 0)
                action = metadata.get("action", "unknown")
                if latency:
                    STEP_LATENCY.labels(action_type=action).observe(latency / 1000.0)

            log_event(
                event_type=event_type,
                status=status,
                component="agent",
                task_id=ctx.task_id,
                step_id=metadata.get("step_id"),
                action=metadata.get("action"),
                latency_ms=metadata.get("latency_ms"),
                payload=metadata
            )

        from app.agent.llm.provider import get_llm_provider
        from app.agent.goal_understanding import LLMGoalInterpreter, DeterministicGoalInterpreter
        from app.agent.planner import LLMPlanner, DeterministicPlanner
        from app.agent.verifier import VerificationEngine, DeterministicVerifier
        import os

        provider = get_llm_provider()

        if os.getenv("LLM_PROVIDER", "mock").lower() == "mock":
            interpreter = DeterministicGoalInterpreter()
            planner = DeterministicPlanner()
            verifier = DeterministicVerifier()
        else:
            interpreter = LLMGoalInterpreter(provider)
            planner = LLMPlanner(provider, action_registry)
            verifier = VerificationEngine(provider)

        policy_engine = PolicyEngine()
        execution_engine = ExecutionEngine(action_registry, policy_engine)
        recovery_engine = RecoveryEngine()

        orchestrator = AgentOrchestrator(
            context=context,
            interpreter=interpreter,
            planner=planner,
            policy_engine=policy_engine,
            execution_engine=execution_engine,
            verifier=verifier,
            recovery_engine=recovery_engine,
            on_state_change=on_state_change,
            on_audit_event=on_audit_event
        )

        original_create_plan = orchestrator.planner.create_plan
        def intercepted_create_plan(goal_under):
            plan = original_create_plan(goal_under)
            save_plan(db, task_id, plan)
            return plan
        orchestrator.planner.create_plan = intercepted_create_plan

        orchestrator.run_lifecycle(goal)
    finally:
        db.close()


@router.post("/", response_model=TaskResponse)
def create_task(task: TaskCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    db_task = DBTask(goal=task.goal, risk_level=task.risk_level, status=AgentState.IDLE.value, user_id=current_user.id)
    db.add(db_task)
    db.commit()
    db.refresh(db_task)
    return db_task

@router.post("/{task_id}/approve")
def approve_task(
    task_id: str,
    background_tasks: BackgroundTasks,
    approved: bool = True,
    reason: str = "",
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    from datetime import datetime, timezone
    from app.models.domain import Task, Approval
    task = db.query(Task).filter(Task.id == task_id, Task.user_id == current_user.id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    approval = db.query(Approval).filter(Approval.task_id == task_id, Approval.status == "PENDING").first()
    if not approval:
        raise HTTPException(status_code=400, detail="No pending approval for this task")

    approval.status = "APPROVED" if approved else "REJECTED"
    approval.decision_at = datetime.now(timezone.utc)
    approval.decision_source = "USER"
    db.commit()

    # Resume the orchestrator in the background
    background_tasks.add_task(resume_agent_lifecycle, task_id, approved, reason)
    return {"status": "resumed", "approved": approved}

def resume_agent_lifecycle(task_id: str, approved: bool, reason: str):
    from app.db.session import SessionLocal
    from app.agent.goal_understanding import DeterministicGoalInterpreter
    from app.agent.planner import DeterministicPlanner
    from app.agent.policy import PolicyEngine
    from app.agent.actions.registry import action_registry
    from app.models.domain import Task, Plan
    from app.repositories.agent_repo import update_task_state, create_approval, save_plan, log_audit_event
    from datetime import datetime, timezone
    from app.core.logging import log_event
    from app.core.metrics import (
        TASKS_COMPLETED, TASKS_FAILED, TASK_DURATION,
        STEP_LATENCY, STEP_VERIFICATION_FAILURES, STEP_RETRIES,
        STEP_REPLANS, STEP_ROLLBACKS, APPROVAL_WAITS, SANDBOX_VIOLATIONS,
        ACTIVE_TASKS
    )
    import time
    db = SessionLocal()
    start_time = time.time()
    try:
        class AgentRepository:
            def __init__(self, db_session):
                self.db = db_session
            def save_state_transition(self, transition, ctx):
                update_task_state(self.db, ctx.task_id, transition.to_state)
                ACTIVE_TASKS.labels(status=transition.to_state.value).inc()
                if transition.from_state:
                    ACTIVE_TASKS.labels(status=transition.from_state.value).dec()

                if transition.to_state == AgentState.COMPLETED:
                    TASKS_COMPLETED.inc()
                    TASK_DURATION.observe(time.time() - start_time)
                elif transition.to_state == AgentState.FAILED:
                    TASKS_FAILED.inc()
                elif transition.to_state == AgentState.WAITING_APPROVAL:
                    APPROVAL_WAITS.inc()
                    create_approval(self.db, transition, ctx)
                elif transition.to_state == AgentState.REPLANNING:
                    STEP_REPLANS.inc()
                elif transition.to_state == AgentState.RETRYING:
                    STEP_RETRIES.inc()
                elif transition.to_state == AgentState.ROLLING_BACK:
                    STEP_ROLLBACKS.inc()

                log_event(
                    event_type="STATE_TRANSITION",
                    status="SUCCESS",
                    component="orchestrator",
                    task_id=ctx.task_id,
                    message=f"Transitioned to {transition.to_state.value}"
                )
            def save_audit_event(self, event_type, status, metadata, ctx):
                log_audit_event(self.db, ctx.task_id, event_type, status, metadata)
                if event_type == "VERIFICATION_COMPLETED" and status == "FAILED":
                    STEP_VERIFICATION_FAILURES.inc()
                if event_type == "POLICY_EVALUATION" and status == "BLOCKED":
                    if metadata.get("reason", "").lower().find("sandbox") != -1:
                        SANDBOX_VIOLATIONS.inc()
                if event_type == "ACTION_EXECUTED" and status == "SUCCESS":
                    latency = metadata.get("latency_ms", 0)
                    action = metadata.get("action", "unknown")
                    if latency:
                        STEP_LATENCY.labels(action_type=action).observe(latency / 1000.0)

                log_event(
                    event_type=event_type,
                    status=status,
                    component="agent",
                    task_id=ctx.task_id,
                    step_id=metadata.get("step_id"),
                    action=metadata.get("action"),
                    latency_ms=metadata.get("latency_ms"),
                    payload=metadata
                )

        repo = AgentRepository(db)

        task = db.query(Task).filter(Task.id == task_id).first()
        plan_model = db.query(Plan).filter(Plan.task_id == task_id).first()

        context = ExecutionContext(task_id=task_id, plan_id=plan_model.id if plan_model else None)

        registry = action_registry
        policy = PolicyEngine()
        from app.agent.executor import ExecutionEngine
        from app.agent.verifier import VerificationEngine
        from app.agent.recovery import RecoveryEngine
        from app.agent.llm.provider import get_llm_provider

        provider = get_llm_provider()

        orchestrator = AgentOrchestrator(
            context=context,
            interpreter=DeterministicGoalInterpreter(),
            planner=DeterministicPlanner(),
            policy_engine=policy,
            execution_engine=ExecutionEngine(registry, policy),
            verifier=VerificationEngine(provider),
            recovery_engine=RecoveryEngine(),
            on_state_change=lambda t, c: repo.save_state_transition(t, c),
            on_audit_event=lambda e, s, m, c: repo.save_audit_event(e, s, m, c)
        )

        # We manually set state to WAITING_APPROVAL
        orchestrator.state_machine.current_state = AgentState.WAITING_APPROVAL

        # Rehydrate plan
        if plan_model:
            from app.agent.models import ExecutionPlan, PlanStep as AgentPlanStep, ActionDefinition
            steps = []
            for smodel in plan_model.steps:
                action = ActionDefinition(action_type=smodel.action_type, parameters=smodel.parameters, risk_level=smodel.risk_level)
                steps.append(AgentPlanStep(step_id=smodel.id, name=smodel.name, action=action, dependencies=smodel.dependencies))
            orchestrator.plan = ExecutionPlan(plan_id=plan_model.id, steps=steps)

        orchestrator.resume_from_approval(approved, reason)
    finally:
        db.close()

@router.get("/", response_model=List[TaskResponse])
def get_tasks(skip: int = 0, limit: int = 100, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    tasks = db.query(DBTask).filter(DBTask.user_id == current_user.id).order_by(DBTask.created_at.desc()).offset(skip).limit(limit).all()
    return tasks

@router.post("/{task_id}/execute")
def execute_task(task_id: str, background_tasks: BackgroundTasks, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    task = db.query(DBTask).filter(DBTask.id == task_id, DBTask.user_id == current_user.id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    if task.status not in [AgentState.IDLE.value, AgentState.FAILED.value, AgentState.CANCELLED.value]:
        raise HTTPException(status_code=400, detail="Task is already executing or completed")

    # Queue background task to not block API
    background_tasks.add_task(run_agent_lifecycle, task_id, task.goal)

    return {"message": "Execution started", "task_id": task_id}

@router.get("/{task_id}/audit")
def get_task_audit(task_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    task = db.query(DBTask).filter(DBTask.id == task_id, DBTask.user_id == current_user.id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    events = get_audit_events(db, task_id)
    return [{"timestamp": e.timestamp, "type": e.event_type, "status": e.payload.get("status"), "payload": e.payload} for e in events]

@router.get("/{task_id}/plan")
def get_task_plan(task_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    task = db.query(DBTask).filter(DBTask.id == task_id, DBTask.user_id == current_user.id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    from app.models.domain import Plan, ActionExecution, Verification
    plan_model = db.query(Plan).filter(Plan.task_id == task_id).order_by(Plan.version.desc()).first()
    if not plan_model:
        return None

    steps = []
    max_risk = 0

    # Build a map of step_id -> audit events from audit trail
    # The orchestrator writes step_id as the original step_id (e.g. "step-os-info"),
    # but the DB stores the compound id as "{plan_id}_{step_id}".
    # We need to match both forms.
    from app.models.domain import AuditEvent as DBAuditEvent
    audit_events = db.query(DBAuditEvent).filter(DBAuditEvent.task_id == task_id).order_by(DBAuditEvent.timestamp).all()

    # Index: logical_step_id -> list of relevant events
    step_events: Dict[str, list] = {}
    for evt in audit_events:
        sid = (evt.payload or {}).get("step_id")
        if sid:
            step_events.setdefault(sid, []).append(evt)

    for s in plan_model.steps:
        # Derive the logical step_id (suffix after plan_id_)
        logical_step_id = s.id
        prefix = f"{plan_model.id}_"
        if s.id.startswith(prefix):
            logical_step_id = s.id[len(prefix):]

        # Determine execution status from audit events
        events_for_step = step_events.get(logical_step_id, [])
        exec_status = "Not executed"
        result_data = None
        verification_data = "Not verified"

        event_types = {e.event_type: e for e in events_for_step}

        if "ACTION_COMPLETED" in event_types:
            exec_status = "SUCCESS"
            result_data = event_types["ACTION_COMPLETED"].payload.get("output")
        elif "ACTION_FAILED" in event_types:
            exec_status = "FAILED"
            result_data = {"error": event_types["ACTION_FAILED"].payload.get("error")}
        elif "ACTION_STARTED" in event_types:
            exec_status = "IN_PROGRESS"

        if "VERIFICATION_COMPLETED" in event_types:
            verif_payload = event_types["VERIFICATION_COMPLETED"].payload or {}
            verification_data = {
                "expected": verif_payload.get("expected_state"),
                "actual": verif_payload.get("actual_state"),
                "passed": verif_payload.get("success", False)
            }

        steps.append({
            "step_id": s.id,
            "logical_step_id": logical_step_id,
            "name": s.name,
            "status": exec_status,
            "dependencies": s.dependencies,
            "action": {
                "action_type": s.action_type,
                "parameters": s.parameters,
                "risk_level": s.risk_level
            },
            "result": result_data,
            "verification": verification_data
        })
        if s.risk_level > max_risk:
            max_risk = s.risk_level

    return {
        "plan_id": plan_model.id,
        "version": plan_model.version,
        "replan_count": max(0, plan_model.version - 1),
        "risk_level": max_risk,
        "steps": steps
    }

@router.get("/{task_id}/timeline")
def get_task_timeline(task_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    task = db.query(DBTask).filter(DBTask.id == task_id, DBTask.user_id == current_user.id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    return {
        "task_id": task_id,
        "status": task.status,
        "created_at": task.created_at
    }

@router.get("/{task_id}/snapshot")
def get_task_snapshot(task_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    task = db.query(DBTask).filter(DBTask.id == task_id, DBTask.user_id == current_user.id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    from app.agent.actions.filesystem_handlers import snapshot_manager
    snapshot = snapshot_manager.get_task_snapshot(task_id)
    if not snapshot:
        return None
    return snapshot.model_dump()

@router.post("/{task_id}/rollback")
def manual_rollback(task_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    task = db.query(DBTask).filter(DBTask.id == task_id, DBTask.user_id == current_user.id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    from app.agent.actions.filesystem_handlers import snapshot_manager
    from app.adapters.linux.filesystem.rollback import RollbackManager

    snapshot = snapshot_manager.get_task_snapshot(task_id)
    if not snapshot:
        raise HTTPException(status_code=404, detail="No snapshot found for this task")

    update_task_state(db, task_id, AgentState.ROLLING_BACK)

    rb_manager = RollbackManager()
    try:
        res = rb_manager.rollback_task(snapshot)
        update_task_state(db, task_id, AgentState.FAILED)
        return {"status": "success", "result": res}
    except Exception as e:
        update_task_state(db, task_id, AgentState.FAILED)
        raise HTTPException(status_code=500, detail=f"Rollback failed: {str(e)}")
